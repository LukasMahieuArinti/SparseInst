import os

FILE_DIR = 'io_files'
TEST_DATA_DIR = 'sample_input_data'
CONVERT_DIR = os.path.join('io_files', 'convert')
PERF_DIR = os.path.join('io_files', 'perf')
# MOUNT_PATH = os.path.join('mnt', 'model')
